// emblem-wallet-connector.js
// ─────────────────────────────────────────────────────────────────────────────
// Emblem Wallet Connector — the shared, app-agnostic multi-chain wallet layer used
// across Emblem front-ends (EmblemWrap / vault-mint, Emblem's Bazaaro World, and any
// other Emblem team project). It handles DISCOVERY, CONNECT, CHAIN-SWITCH and SIGNING
// only. It has NO DOM and NO server calls, so it drops into any page: your app keeps
// its own server/holdings/wrap logic and asks this connector for an address + signer.
//
// Chains: EVM (EIP-6963 + injected: MetaMask/Rabby/Coinbase/OKX/Rainbow/Phantom/
// Robinhood/… with Base/Polygon/Shape/Robinhood chain add+switch), Solana (Phantom/
// Solflare/Backpack/OKX), Bitcoin Ordinals (Unisat + Xverse via sats-connect), and
// Counterparty (XCP Wallet).
//
// Usage (ES module):
//   import { createEmblemWallet } from './emblem-wallet-connector.js';
//   const wallet = createEmblemWallet({ onWalletChange:(chain,addr)=>{...} });
//   const addr = await wallet.connectEvm('metamask');
//   await wallet.ensureChain(wallet.CHAIN_HEX.Base);
//   const client = wallet.emblemClient();          // feeds emblem-vault-sdk mint/claim
//
// A ready singleton is also exposed as window.EmblemWallet.
// Version is exported as EMBLEM_WALLET_CONNECTOR_VERSION; bump on every change.
// ─────────────────────────────────────────────────────────────────────────────
import { BrowserProvider, isAddress, getAddress } from 'https://esm.sh/ethers@6.17.0';

export const EMBLEM_WALLET_CONNECTOR_VERSION = '1.2.0';

// sats-connect is only needed for Xverse; load it lazily so BTC-less apps pay nothing.
let _scMod = null;
async function loadSatsConnect(){
  if(_scMod) return _scMod;
  const url = 'https://esm.sh/sats-connect@4.2.1?bundle';
  for(let i=0;i<2;i++){ try{ _scMod = await import(url); return _scMod; }catch(e){ if(i) throw new Error('Could not load the Bitcoin wallet library. Check your connection and retry.'); await new Promise(r=>setTimeout(r,700)); } }
  throw new Error('Could not load the Bitcoin wallet library. Check your connection and retry.');
}

export function createEmblemWallet(ctx){
  const { onWalletChange = ()=>{} } = ctx || {};

  // Connected wallet state. Full addresses are kept for holdings + sends; evmSigner is the
  // ethers v6 signer reused for message signing and transactions.
  let evmProvider=null, evmSigner=null, evmEip1193=null, evmAddress=null, evmWalletId=null,
      solAddress=null, solWalletId=null,
      btcAddress=null, btcOrdinalsPubkey=null, btcPaymentAddress=null, btcPaymentPubkey=null, btcWalletId=null,
      xcpAddrs=[], xcpProviderId=null;

  // ── EVM: EIP-6963 discovery ──────────────────────────────────────────────
  // With several wallets installed, window.ethereum and the spoofable isMetaMask flag are
  // unreliable (e.g. Temple sets isMetaMask=true). EIP-6963 has each wallet announce a unique
  // rdns, so we select the exact wallet unspoofably. Legacy injected pick is the fallback.
  const _eip6963 = new Map();   // rdns(lower) → provider
  try{ window.addEventListener('eip6963:announceProvider', e=>{ try{ const d=e&&e.detail; if(d&&d.info&&d.info.rdns&&d.provider) _eip6963.set(String(d.info.rdns).toLowerCase(), d.provider); }catch(_){} }); window.dispatchEvent(new Event('eip6963:requestProvider')); }catch(_){}
  const EVM_RDNS = { metamask:['io.metamask','io.metamask.flask','io.metamask.mmi'], rabby:['io.rabby'], phantom:['app.phantom'], coinbase:['com.coinbase.wallet'], okx:['com.okex.wallet'], trust:['com.trustwallet.app'], rainbow:['me.rainbow'], zerion:['io.zerion.wallet'], brave:['com.brave.wallet'], frame:['sh.frame'], bitget:['com.bitget.web3'], enkrypt:['com.enkrypt'], taho:['com.taho','com.tahowallet'], robinhood:['com.robinhood.wallet'] };
  function findEip6963(id){ try{ window.dispatchEvent(new Event('eip6963:requestProvider')); }catch(_){} const keys=EVM_RDNS[id]; if(!keys) return null; for(const k of keys){ const p=_eip6963.get(k); if(p) return p; } return null; }
  function findInjectedEvm(id){
    const p6963 = findEip6963(id); if(p6963) return p6963;
    const eth = window.ethereum;
    const list = (eth && eth.providers) || [];
    const pick = pred => list.find(pred) || (eth && pred(eth) ? eth : null);
    if(id==='robinhood') return pick(p=>p&&(p.isRobinhood||p.isRobinhoodWallet)) || window.robinhoodWallet || null;
    if(id==='metamask') return pick(p=>p&&p.isMetaMask&&!p.isRabby);
    if(id==='rabby')    return pick(p=>p&&p.isRabby) || window.rabby || null;
    if(id==='phantom')  return (window.phantom&&window.phantom.ethereum) || pick(p=>p&&p.isPhantom) || null;
    if(id==='coinbase') return pick(p=>p&&p.isCoinbaseWallet) || window.coinbaseWalletExtension || null;
    if(id==='okx')      return window.okxwallet || pick(p=>p&&p.isOkxWallet) || null;
    if(id==='trust')    return window.trustwallet || pick(p=>p&&p.isTrust) || null;
    if(id==='brave')    return pick(p=>p&&p.isBraveWallet) || null;
    if(id==='rainbow')  return pick(p=>p&&p.isRainbow) || null;
    if(id==='zerion')   return pick(p=>p&&p.isZerion) || null;
    if(id==='frame')    return pick(p=>p&&p.isFrame) || null;
    if(id==='bitget')   return (window.bitkeep&&window.bitkeep.ethereum) || pick(p=>p&&p.isBitKeep) || null;
    if(id==='enkrypt')  return (window.enkrypt&&window.enkrypt.providers&&window.enkrypt.providers.ethereum) || null;
    if(id==='taho')     return window.tally || pick(p=>p&&p.isTally) || null;
    return eth || null;
  }
  // Which of the known EVM wallets are actually present right now (for building a connect menu).
  function discoverEvm(){ return Object.keys(EVM_RDNS).filter(id=>{ try{ return !!findInjectedEvm(id); }catch(e){ return false; } }); }

  function wireEvmAccountEvents(eip){
    if(!eip || !eip.on || eip._embAcctWired) return;
    eip._embAcctWired = true;
    eip.on('accountsChanged', async (accts)=>{
      try{
        const raw = (accts && accts[0]) || null;
        // Some wallets emit a lowercase address; Emblem's index is case-sensitive, so ALWAYS store EIP-55 checksummed.
        let a = null; if(raw){ try{ a = getAddress(raw); }catch(e){ a = raw; } }
        if(a){ evmAddress = a; try{ evmProvider = new BrowserProvider(eip); evmSigner = await evmProvider.getSigner(a); }catch(e){} }
        else { evmAddress = null; evmSigner = null; }
        try{ onWalletChange('eth', a); }catch(_){}
      }catch(_){}
    });
  }
  async function connectEvm(id){
    const eip1193 = findInjectedEvm(id);
    if(!eip1193) throw new Error(`${id} not found. Is it installed?`);
    await eip1193.request({ method:'eth_requestAccounts' });
    try{ await eip1193.request({ method:'wallet_switchEthereumChain', params:[{ chainId:'0x1' }] }); }
    catch(e){ throw new Error(`Switch ${id} to Ethereum mainnet`); }
    evmEip1193 = eip1193;
    evmProvider = new BrowserProvider(eip1193);
    evmSigner = await evmProvider.getSigner();
    const a = await evmSigner.getAddress();
    if(!isAddress(a)) throw new Error('Invalid EVM address');
    evmAddress = a; evmWalletId = id;
    wireEvmAccountEvents(eip1193);
    try{ onWalletChange('eth', a); }catch(_){}
    return a;
  }
  // Re-attach an already-authorized injected wallet WITHOUT a popup (eth_accounts returns granted account, [] if not).
  async function attachEvmSilently(id){
    if(!id) return null;
    const eip = findInjectedEvm(id);
    if(!eip || !eip.request) return null;
    const accs = await eip.request({ method:'eth_accounts' });
    if(!accs || !accs.length) return null;
    evmEip1193 = eip;
    evmProvider = new BrowserProvider(eip);
    evmSigner = await evmProvider.getSigner(accs[0]);
    const a = await evmSigner.getAddress();
    if(!isAddress(a)) return null;
    evmAddress = a; evmWalletId = id;
    wireEvmAccountEvents(eip);
    try{ onWalletChange('eth', a); }catch(_){}
    return a;
  }
  async function ensureEvm(){
    if(!evmAddress){ if(evmWalletId){ try{ await attachEvmSilently(evmWalletId); }catch(e){} } return evmAddress; }
    try{
      if(evmEip1193){
        const accs = await evmEip1193.request({ method:'eth_accounts' });
        const cur = accs && accs[0];
        if(cur && cur.toLowerCase() !== evmAddress.toLowerCase()){
          evmProvider = new BrowserProvider(evmEip1193);
          evmSigner = await evmProvider.getSigner(cur);
          evmAddress = await evmSigner.getAddress();
        }
      }
    }catch(e){}
    return evmAddress;
  }

  // ── EVM chain switching (source chain for a send, ETH mainnet for the mint) ──
  const CHAIN_HEX = { Ethereum:'0x1', Base:'0x2105', Polygon:'0x89', Shape:'0x168', Robinhood:'0x1237' };
  const CHAIN_ADD_PARAMS = {
    '0x168':  { chainId:'0x168',  chainName:'Shape',          nativeCurrency:{ name:'Ether', symbol:'ETH', decimals:18 }, rpcUrls:['https://mainnet.shape.network'],           blockExplorerUrls:['https://shapescan.xyz'] },
    '0x1237': { chainId:'0x1237', chainName:'Robinhood Chain', nativeCurrency:{ name:'Ether', symbol:'ETH', decimals:18 }, rpcUrls:['https://rpc.mainnet.chain.robinhood.com'], blockExplorerUrls:['https://robinhoodchain.blockscout.com'] },
    '0x2105': { chainId:'0x2105', chainName:'Base',           nativeCurrency:{ name:'Ether', symbol:'ETH', decimals:18 }, rpcUrls:['https://mainnet.base.org'],                blockExplorerUrls:['https://basescan.org'] },
    '0x89':   { chainId:'0x89',   chainName:'Polygon',        nativeCurrency:{ name:'POL',   symbol:'POL', decimals:18 }, rpcUrls:['https://polygon-rpc.com'],                blockExplorerUrls:['https://polygonscan.com'] },
  };
  async function ensureChain(hex){
    if(!evmEip1193) throw new Error('Connect an EVM wallet');
    const cur = await evmEip1193.request({ method:'eth_chainId' });
    if(cur !== hex){
      try{ await evmEip1193.request({ method:'wallet_switchEthereumChain', params:[{ chainId:hex }] }); }
      catch(err){
        const code = (err && (err.code ?? (err.data && err.data.originalError && err.data.originalError.code)));
        if((code===4902 || /unrecogni[sz]ed|add[^.]*chain|not been added/i.test(String((err&&err.message)||''))) && CHAIN_ADD_PARAMS[hex]){
          await evmEip1193.request({ method:'wallet_addEthereumChain', params:[ CHAIN_ADD_PARAMS[hex] ] });
          await evmEip1193.request({ method:'wallet_switchEthereumChain', params:[{ chainId:hex }] });
        } else throw err;
      }
    }
    evmProvider = new BrowserProvider(evmEip1193);
    evmSigner = await evmProvider.getSigner();
  }

  // SDK client adapter: an ethers v6 Signer satisfies emblem-vault-sdk's EvmSigner; add the setChainId()
  // the SDK expects, and coerce ethers-v5 BigNumber-like tx fields to native bigint (the claim/unwrap path).
  function emblemClient(){
    return { async toEthersWallet(){
      if(!evmSigner) throw new Error('Connect an EVM wallet first');
      evmSigner.setChainId = async ()=>{};
      if(!evmSigner._embBnWrapped){
        const orig = evmSigner.sendTransaction.bind(evmSigner);
        evmSigner.sendTransaction = (tx)=>{
          if(tx && typeof tx==='object'){
            for(const k of ['value','gasLimit','gasPrice','maxFeePerGas','maxPriorityFeePerGas','nonce']){
              const v=tx[k];
              if(v!=null && typeof v==='object' && typeof v.toString==='function'){ try{ tx[k]=BigInt(v.toString()); }catch(e){} }
            }
          }
          return orig(tx);
        };
        evmSigner._embBnWrapped = true;
      }
      return evmSigner;
    } };
  }

  // ── Solana (injected) ────────────────────────────────────────────────────
  const SOL = {
    phantom: ()=> (window.phantom&&window.phantom.solana) || (window.solana&&window.solana.isPhantom?window.solana:null),
    solflare:()=> window.solflare || null,
    backpack:()=> window.backpack || (window.xnft&&window.xnft.solana) || null,
    okx:     ()=> (window.okxwallet&&window.okxwallet.solana) || null,
  };
  function discoverSolana(){ return Object.keys(SOL).filter(id=>{ try{ return !!SOL[id](); }catch(e){ return false; } }); }
  function solProvider(){ return (solWalletId && SOL[solWalletId] && SOL[solWalletId]()) || SOL.phantom() || window.solflare || window.backpack || window.solana || null; }
  async function connectSolana(id){
    const prov = (SOL[id]||(()=>null))();
    if(!prov) throw new Error(`${id} (Solana) not found. Is it installed?`);
    const res = await prov.connect();
    const pk = (res&&res.publicKey) || prov.publicKey;
    const s = pk.toString();
    solAddress = s; solWalletId = id;
    try{ onWalletChange('sol', s); }catch(_){}
    return s;
  }

  // ── Bitcoin Ordinals: Unisat + Xverse (sats-connect) ─────────────────────
  async function connectBtc(id){
    btcWalletId = id;
    if(id==='unisat') return connectUnisat();
    return connectXverse();
  }
  async function connectUnisat(){
    if(!window.unisat || !window.unisat.requestAccounts) throw new Error('Unisat not detected. Is it installed?');
    const accts = await window.unisat.requestAccounts();
    const addr = accts && accts[0];
    if(!addr) throw new Error('Unisat connection was denied or cancelled');
    if(!/^bc1p/i.test(addr)) throw new Error('Switch Unisat to a Taproot (bc1p) address for ordinals, then reconnect');
    let pub=''; try{ pub = await window.unisat.getPublicKey(); }catch(e){}
    btcAddress = addr; btcOrdinalsPubkey = pub; btcPaymentAddress = addr; btcPaymentPubkey = pub;
    try{ onWalletChange('btc', addr); }catch(_){}
    return addr;
  }
  async function ensureBtc(){
    if(btcAddress) return btcAddress;
    if(btcWalletId){ try{ return await connectBtc(btcWalletId); }catch(e){} }
    return btcAddress;
  }
  async function connectXverse(){
    const sc = await loadSatsConnect();
    const request = sc.request || (sc.default && sc.default.request);
    const AP = sc.AddressPurpose || { Ordinals:'ordinals', Payment:'payment' };
    if(!request) throw new Error('sats-connect request() not available');
    const isTap = a => /^bc1p/i.test((a&&a.address)||'');
    const pick = (res)=>{
      if(!res || res.status!=='success') return null;
      const addrs = (res.result && res.result.addresses) || [];
      const ord = addrs.find(a=>/ordinal/i.test(a.purpose) && isTap(a))
               || addrs.find(a=>isTap(a))
               || addrs.find(a=>/p2tr|taproot/i.test(a.addressType||''));
      const pay = addrs.find(a=>/payment/i.test(a.purpose)) || addrs.find(a=>/^(bc1q|3)/i.test(a.address||''));
      return ord ? { ord:ord.address, ordPub:ord.publicKey||'', pay:(pay&&pay.address)||null, payPub:(pay&&pay.publicKey)||'' } : null;
    };
    let hit=null, lastErr='';
    try{ const r=await request('wallet_connect', { addresses:[AP.Ordinals, AP.Payment], message:'Connect to Emblem' }); hit=pick(r); lastErr=r&&r.error&&r.error.message; }catch(e){ lastErr=e&&e.message; }
    if(!hit){ try{ const r=await request('wallet_connect', null); hit=pick(r); lastErr=(r&&r.error&&r.error.message)||lastErr; }catch(e){} }
    if(!hit){ try{ const r=await request('getAddresses', { purposes:[AP.Ordinals, AP.Payment], message:'Connect to Emblem' }); hit=pick(r); lastErr=(r&&r.error&&r.error.message)||lastErr; }catch(e){} }
    if(!hit) throw new Error(lastErr || 'Xverse connection was denied or cancelled');
    btcAddress = hit.ord; btcOrdinalsPubkey = hit.ordPub; btcPaymentAddress = hit.pay; btcPaymentPubkey = hit.payPub;
    try{ onWalletChange('btc', hit.ord); }catch(_){}
    return hit.ord;
  }

  // ── Counterparty: XCP Wallet (EIP-1193 style, window.xcpwallet) ──────────
  function xcpProvider(){ try{ return (window.xcpwallet && typeof window.xcpwallet.request==='function') ? window.xcpwallet : null; }catch(e){ return null; } }
  function xcpAvailable(){ return !!xcpProvider(); }
  // Returns [{address, purpose, type}] with the legacy (1.../3...) address first — Counterparty assets live there.
  async function connectXcp(silent){
    const P = xcpProvider();
    if(!P || typeof P.request!=='function'){ if(silent) return []; throw new Error('XCP Wallet not detected. Install the XCP Wallet extension (desktop) and reload.'); }
    const _emb = (()=>{ try{ return window.top!==window.self; }catch(_){ return true; } })();
    const _isCancel = e=> (e&&e.code)===4001 || /reject|denied|cancel|\buser\b|4001/i.test((e&&(e.message||e.reason))||String(e));
    const _req = (args,ms)=> Promise.race([ P.request(args), new Promise((_,rej)=>setTimeout(()=>{ const t=new Error('timed out'); t.__to=true; rej(t); }, ms||45000)) ]);
    const RX=/(bc1[a-z0-9]{20,}|[13][a-km-zA-HJ-NP-Z1-9]{20,})/;
    const seen=new Set(); const addrs=[];
    const push=s=>{ const m=String(s||'').match(RX); if(!m) return; const a=m[0]; if(!seen.has(a)){ seen.add(a); addrs.push({ address:a, purpose:/^bc1/i.test(a)?'ordinals':'payment', type:/^bc1/i.test(a)?'segwit':'legacy' }); } };
    const asAddr=o=> (o && (o.address||o.addr||o.value||o.p2pkh||o.legacy))||'';
    const collect=v=>{ if(v==null) return;
      if(typeof v==='string'){ push(v); return; }
      if(Array.isArray(v)){ v.forEach(collect); return; }
      if(typeof v==='object'){ const d=asAddr(v); if(d) push(d); for(const k of Object.keys(v)){ const val=v[k]; if(typeof val==='string') push(val); else if(val && typeof val==='object') collect(val); } }
    };
    const haveLegacy=()=> addrs.some(a=>/^[13]/.test(a.address));
    let ac=null; try{ ac = await _req({ method:'xcp_accounts' }, 15000); }catch(e){} collect((ac&&ac.result)||ac);
    let g=null;
    if(!haveLegacy()){ try{ g = await _req({ method:'xcp_getAddresses' }, 15000); }catch(e){} collect((g&&g.result)||g); }
    let ra=null;
    if(!addrs.length && silent) return [];
    if(!addrs.length){
      try{ ra = await _req({ method:'xcp_requestAccounts', params:[{ capabilities:{ pairedAddresses:true } }] }, 120000); }
      catch(e){
        if(_isCancel(e)) throw new Error('__CP_CANCELLED__');
        try{ ra = await _req({ method:'xcp_requestAccounts' }, 120000); }
        catch(e2){
          if(_isCancel(e2)) throw new Error('__CP_CANCELLED__');
          const em2=(e2&&(e2.message||e2.reason))||String(e2);
          if((e2&&e2.__to) || _emb || /storage is not allowed|not allowed from this context/i.test(em2))
            throw new Error('XCP Wallet approved but the connection never came back. Open the site in its own browser tab, unlock the extension, and reconnect.');
          throw new Error('XCP Wallet could not complete the request ('+em2+'). Make sure the extension is unlocked and a Legacy (1…) account is enabled, then reconnect.');
        }
      }
      collect((ra&&ra.result)||ra);
      if(!haveLegacy()){ try{ g = await _req({ method:'xcp_getAddresses' }, 15000); }catch(e){} collect((g&&g.result)||g); }
      // xcp_requestAccounts can resolve before the user finishes unlocking; poll ~60s so the grant lands with one click.
      for(let i=0;i<24 && !addrs.length;i++){
        await new Promise(r=>setTimeout(r,2500));
        try{ const a2=await _req({ method:'xcp_accounts' }, 8000); collect((a2&&a2.result)||a2); }catch(e){}
        if(!haveLegacy()){ try{ const g2=await _req({ method:'xcp_getAddresses' }, 8000); collect((g2&&g2.result)||g2); }catch(e){} }
      }
    }
    if(!addrs.length) throw new Error('XCP Wallet connected but no Bitcoin address could be read from its reply.');
    addrs.sort((a,b)=> (a.type==='legacy'?0:1) - (b.type==='legacy'?0:1));
    xcpAddrs = addrs; xcpProviderId = 'xcpwallet';
    try{ localStorage.setItem('emblem-wallet:xcpAddrs', JSON.stringify(addrs)); localStorage.setItem('emblem-wallet:xcpProviderId','xcpwallet'); }catch(e){}
    try{ onWalletChange('xcp', addrs[0] && addrs[0].address); }catch(_){}
    return addrs;
  }

  // ── Counterparty: Horizon Wallet (sats-connect provider, window.btc_providers / window.HorizonWalletProvider) ──
  // Horizon registers as "HorizonWalletProvider" in the sats-connect registry and speaks the sats-connect standard
  // (same contract as Xverse). We select it EXPLICITLY by id so we never sign through the wrong Bitcoin wallet.
  // Desktop-only browser extension. Populates the SHARED xcpAddrs (legacy-first) so the CP reader/wrap paths are wallet-agnostic.
  function horizonProvider(){ try{
    const g = window.HorizonWalletProvider; if(g && typeof g.request==='function') return g;
    const e = Array.isArray(window.btc_providers) && window.btc_providers.find(p=>p&&p.id==='HorizonWalletProvider');
    if(e){ if(typeof e.request==='function') return e; if(e.provider && typeof e.provider.request==='function') return e.provider; }
    return (g && typeof g.request==='function') ? g : null;
  }catch(e){ return null; } }
  function horizonAvailable(){ try{ return !!(horizonProvider() || (Array.isArray(window.btc_providers) && window.btc_providers.find(p=>p&&p.id==='HorizonWalletProvider'))); }catch(e){ return false; } }
  async function connectHorizon(){
    const P = horizonProvider();
    if(!P || typeof P.request!=='function') throw new Error('Horizon Wallet not detected. Install the Horizon extension (desktop) and reload.');
    const _isCancel = e=> (e&&e.code)===4001 || /reject|denied|cancel|\buser\b|4001/i.test((e&&(e.message||e.reason))||String(e));
    let res=null, err1='';
    try{ res = await P.request('getAddresses', { purposes:['payment','ordinals'], message:'Connect to Bazaaro' }); }
    catch(e){ if(_isCancel(e)) throw new Error('__CP_CANCELLED__'); err1=(e&&(e.message||e.reason))||String(e);
      try{ res = await P.request('wallet_connect', { addresses:['payment','ordinals'] }); }
      catch(e2){ if(_isCancel(e2)) throw new Error('__CP_CANCELLED__'); throw new Error('Horizon connect failed: '+err1+' / '+((e2&&(e2.message||e2.reason))||e2)); } }
    const r = (res&&res.result) || res || {};
    const raw = r.addresses || (r.result&&r.result.addresses) || [];
    let addrs = raw.map(a=>({ address:a.address||a.addr, purpose:a.purpose||a.type||'', type:(/^[13]/.test(a.address||a.addr||'')?'legacy':(a.addressType||a.type||'')) })).filter(a=>a.address);
    if(!addrs.length) throw new Error('Horizon returned no addresses. Re-open the connect prompt and choose “All Addresses in Account”.');
    addrs.sort((a,b)=> (/^[13]/.test(a.address)?0:1) - (/^[13]/.test(b.address)?0:1));   // legacy (Counterparty-capable) first
    xcpAddrs = addrs; xcpProviderId = 'horizon';
    try{ localStorage.setItem('emblem-wallet:xcpAddrs', JSON.stringify(addrs)); localStorage.setItem('emblem-wallet:xcpProviderId','horizon'); }catch(e){}
    try{ onWalletChange('xcp', addrs[0] && addrs[0].address); }catch(_){}
    return addrs;
  }
  // Sign a PSBT with Horizon (sats-connect). Accepts hex OR base64; Horizon wants base64. signInputs is { addr:[indices] }.
  // Horizon SIGNS ONLY (broadcast:false) and reports failures as a resolved value with an .error field, so we check it.
  // Returns the signed PSBT (base64) for our server to finalize+broadcast, unless Horizon already returned a txid.
  async function horizonSignPsbt(psbtHexOrB64, signInputs, opts){
    const P = horizonProvider(); if(!P) throw new Error('Horizon Wallet not detected.');
    const looksHex = /^[0-9a-fA-F]+$/.test(String(psbtHexOrB64||'')) && (String(psbtHexOrB64).length % 2 === 0);
    const b64 = looksHex ? hexToB64(psbtHexOrB64) : psbtHexOrB64;   // same bytes, re-encoded — no bitcoinjs needed
    let s;
    try{ s = await P.request('signPsbt', Object.assign({ psbt:b64, signInputs, broadcast:false }, opts||{})); }
    catch(e){ const em=(e&&(e.message||e.reason))||String(e); if(/reject|denied|cancel|\buser\b|4001|ACTION_REJECTED/i.test(em)) throw new Error('__CP_CANCELLED__'); throw e; }
    if(s && s.error){ const em=String((s.error&&s.error.message)||JSON.stringify(s.error)); if(/reject|denied|cancel|\buser\b|4001/i.test(em)) throw new Error('__CP_CANCELLED__'); throw new Error('Horizon could not sign the send: '+em); }
    const sr = (s&&s.result)||s||{};
    const txid = sr.txid||sr.txId||sr.txHash||sr.transactionId||sr.tx_hash||sr.tx||sr.id||null;
    const signed = sr.psbt||sr.signedPsbt||sr.signedPsbtBase64||sr.psbtBase64||sr.signedPsbtHex||sr.hex||(typeof sr==='string'?sr:null);
    return { txid, signed };
  }
  function hexToB64(hex){ const s=String(hex); let bin=''; for(let i=0;i<s.length;i+=2){ bin+=String.fromCharCode(parseInt(s.substr(i,2),16)); } return btoa(bin); }
  // Route a CP sign to whichever Counterparty wallet is connected: XCP Wallet (hex) or Horizon (base64 sats-connect).
  async function cpSignPsbt(psbtHex, signInputs, opts){
    if(xcpProviderId==='horizon') return horizonSignPsbt(psbtHex, signInputs, opts);
    const raw = await xcpSignPsbtHex(psbtHex, signInputs, opts);   // XCP Wallet: returns a hex string (or a wrapper object)
    const signed = (raw && (raw.hex||raw.signedPsbtHex||raw.psbt||raw.signedPsbt||raw.psbtBase64))||(typeof raw==='string'?raw:null);
    return { txid:(raw&&(raw.txid||raw.txId))||null, signed };
  }
  // Sign a PSBT with XCP Wallet. `signInputs` is an object keyed by owning address: { addr:[indices] }.
  async function xcpSignPsbtHex(psbtHex, signInputs, opts){
    const P = xcpProvider(); if(!P) throw new Error('XCP Wallet not detected.');
    const params = Object.assign({ hex:psbtHex, signInputs }, opts||{});   // XCP Wallet expects { hex, signInputs } (per XCP/extension PROVIDER.md)
    const r = await P.request({ method:'xcp_signPsbt', params:[params] });
    return (r && (r.result || r.psbt || r)) || r;
  }

  // Send an ordinal/inscription to `toAddress` via the connected BTC wallet's high-level API (no PSBT building).
  async function sendOrdinal(toAddress, inscriptionId, feeRate){
    const idStr = String(inscriptionId||''); if(!toAddress || !idStr) throw new Error('Missing destination or inscription id');
    if((btcWalletId==='unisat') || (!btcWalletId && window.unisat && window.unisat.sendInscription)){
      if(!window.unisat || !window.unisat.sendInscription) throw new Error('Unisat is not available for sending.');
      const r = await window.unisat.sendInscription(toAddress, idStr, feeRate?{ feeRate }:undefined);
      return (r && (r.txid || r)) || r;
    }
    const sc = await loadSatsConnect(); const request = sc.request || (sc.default && sc.default.request);
    if(!request) throw new Error('Xverse is not available for sending.');
    const r = await request('ord_sendInscriptions', { transfers:[{ address:toAddress, inscriptionId:idStr }] });
    if(!r || r.status!=='success') throw new Error((r && r.error && r.error.message) || 'Inscription send was cancelled.');
    return (r.result && (r.result.txid || r.result.txId)) || r.result;
  }

  return {
    version: EMBLEM_WALLET_CONNECTOR_VERSION,
    // EVM
    discoverEvm, findInjectedEvm, connectEvm, attachEvmSilently, ensureEvm, ensureChain, emblemClient, CHAIN_HEX, CHAIN_ADD_PARAMS,
    // Solana
    discoverSolana, solProvider, connectSolana,
    // Bitcoin
    connectBtc, connectUnisat, connectXverse, ensureBtc, sendOrdinal,
    // Counterparty
    xcpAvailable, connectXcp, xcpSignPsbtHex,
    horizonAvailable, connectHorizon, cpSignPsbt,
    get xcpProviderId(){ return xcpProviderId; },
    // state getters (read-only snapshots)
    get evmAddress(){ return evmAddress; }, get evmSigner(){ return evmSigner; }, get evmProvider(){ return evmProvider; }, get evmEip1193(){ return evmEip1193; }, get evmWalletId(){ return evmWalletId; },
    get solAddress(){ return solAddress; }, get solWalletId(){ return solWalletId; },
    get btcAddress(){ return btcAddress; }, get btcPaymentAddress(){ return btcPaymentAddress; }, get btcOrdinalsPubkey(){ return btcOrdinalsPubkey; }, get btcPaymentPubkey(){ return btcPaymentPubkey; }, get btcWalletId(){ return btcWalletId; },
    get xcpAddrs(){ return xcpAddrs.slice(); },
    get state(){ return { evmAddress, evmWalletId, solAddress, solWalletId, btcAddress, btcPaymentAddress, btcWalletId, xcpAddrs:xcpAddrs.slice() }; },
  };
}

// Ready-to-use singleton for script-tag / non-bundler consumers.
try{ if(typeof window!=='undefined' && !window.EmblemWallet){ window.EmblemWallet = createEmblemWallet({}); } }catch(e){}
